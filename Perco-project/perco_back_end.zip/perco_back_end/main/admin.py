from django.contrib import admin
from .models import Info_email,Info_article

admin.site.register(Info_email)
admin.site.register(Info_article)

# Register your models here.
